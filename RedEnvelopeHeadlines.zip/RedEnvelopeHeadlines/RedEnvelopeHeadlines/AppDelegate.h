//
//  AppDelegate.h
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

