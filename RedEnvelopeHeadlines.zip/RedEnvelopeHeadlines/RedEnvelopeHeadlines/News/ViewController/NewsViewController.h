//
//  NewsViewController.h
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "BaseViewController.h"

@interface NewsViewController : BaseViewController

@end
