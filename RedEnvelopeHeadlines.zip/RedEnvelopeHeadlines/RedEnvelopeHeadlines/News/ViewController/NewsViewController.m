//
//  NewsViewController.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "NewsViewController.h"
#import "HRHeaderConfigPlist.h"
#import "HRSegmentView.h"
#import "HRNewsHeaderModel.h"
#import "SinglePictureNewsTableViewCell.h"
#import "MultiPictureTableViewCell.h"
#import "UserStore.h"
#import <MJRefresh/MJRefresh.h>
#import "HRNewsModel.h"
#import "HRWebViewController.h"
#import "SuspensionView.h"
#import "RedBagSignInMainView.h"

static NSString * const singlePictureCell = @"SinglePictureCell";
static NSString * const multiPictureCell = @"MultiPictureCell";
@interface NewsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, assign) NSInteger      currentPage;
@property (nonatomic, strong) UITableView *newsTableView;
@property (nonatomic, strong) HRNewsHeaderModel *selectedNewsModel;
@property (nonatomic, strong) NSMutableArray *newsDataList;

@end

@implementation NewsViewController
- (instancetype)init{
    self = [super init];
    if (self) {
        
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   self.navigationController.navigationBarHidden = YES;
     
    [self setupBasic];
     [self setupRefresh];
    
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
}
-(void)setupBasic{
  
    NSArray *arr = [HRHeaderConfigPlist localHeaderData];

    HRSegmentView *segmentView = [[HRSegmentView alloc]initWithFrame:CGRectMake(0, 20, kScreenWidth, 44) titles:arr headerType:@"news" clickBlick:^(NSInteger index) {
        _selectedNewsModel = arr[index];
        if (_selectedNewsModel.name) {
            [self loadData]; 
        }
       
    }];
    [self.view addSubview:segmentView];
    self.newsTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 65, kScreenWidth, CGRectGetHeight(self.view.frame)-tabBarHeight-65) style:UITableViewStylePlain];
    self.newsTableView.delegate = self;
    self.newsTableView.dataSource = self;
    [self.view addSubview:self.newsTableView];
    [self.newsTableView registerNib:[UINib nibWithNibName:NSStringFromClass([SinglePictureNewsTableViewCell class]) bundle:nil] forCellReuseIdentifier:singlePictureCell];
    [self.newsTableView registerNib:[UINib nibWithNibName:NSStringFromClass([MultiPictureTableViewCell class]) bundle:nil] forCellReuseIdentifier:multiPictureCell];
    self.newsTableView.tableFooterView = [[UIView alloc]init];
   NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"suspensionView" owner:nil options:nil];
    SuspensionView *suspensionView = [nibView objectAtIndex:0];
    suspensionView.frame = new_suspensionViewFram;
    suspensionView.isKeepBounds = YES;
    suspensionView.signDesText = @"获得金币";
    suspensionView.signText = @"签到";
     [self.view addSubview:suspensionView];
    //限定logoView的活动范围
    
    suspensionView.ClickDragViewBlock = ^(SuspensionView *dragView){
        NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"SignMainView" owner:nil options:nil];
        RedBagSignInMainView *redBagView = [nibView objectAtIndex:0];
        [redBagView show];
    };
}
#pragma mark --private Method--初始化刷新控件
-(void)setupRefresh {
    self.newsTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    self.newsTableView.mj_header.automaticallyChangeAlpha = YES;
    [self.newsTableView.mj_header beginRefreshing];
    self.newsTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    self.currentPage = 1;
}
#pragma mark - /************************* 刷新数据 ***************************/
// ------下拉刷新
- (void)loadData
{
    _currentPage = 1;
    [self loadDataForType:ScrollDirectionDown];
}

- (void)loadMoreData
{
    _currentPage +=1;
    [self loadDataForType:ScrollDirectionUp];
    
}
- (void)loadDataForType:(ScrollDirection)type{
     __weak NewsViewController *weakSelf = self;
   
    [[UserStore sharedInstance]loadNewsDataForType:type newsType:_selectedNewsModel.name page:_currentPage ssucessBlock:^(NSURLSessionDataTask *task, id responseObject) {
        id value = [responseObject objectForKey:@"data"];
        if ([value isKindOfClass:[NSArray class]]){
            NSArray *dataArr = (NSArray *)value;
            NSArray *arrayM = [HRNewsModel mj_objectArrayWithKeyValuesArray:dataArr];
            if (type == ScrollDirectionDown) {
                weakSelf.newsDataList = [arrayM mutableCopy];
                [weakSelf.newsTableView.mj_header endRefreshing];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.newsTableView reloadData];
                    [weakSelf.newsTableView.mj_header endRefreshing];
                });
            }else if(type == ScrollDirectionUp){
                [weakSelf.newsDataList addObjectsFromArray:arrayM];
                [weakSelf.newsTableView.mj_footer endRefreshing];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.newsTableView reloadData];
                    [weakSelf.newsTableView.mj_footer endRefreshing];
                });
            }
           
        }
    } failureBlock:^(NSURLSessionDataTask *task, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.newsTableView.mj_header endRefreshing];
            [weakSelf.newsTableView.mj_footer endRefreshing];
        });
    }];
}





#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.newsDataList.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    HRNewsModel *listM = self.newsDataList[indexPath.row];
    if (listM.image_list.count == 1) {
        return 110;
    }else{
        return 170;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HRNewsModel *listM = self.newsDataList[indexPath.row];
    
    if (listM.image_list.count ==1) {
        SinglePictureNewsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:singlePictureCell];
        cell.normalNews = listM;
        
        return cell;
    }else{
        
        MultiPictureTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:multiPictureCell];
        
        cell.normalNews = listM;
        return cell;
    }
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HRNewsModel *listM = self.newsDataList[indexPath.row];
    NSString *imageUrl;
    if (listM.image_list.count > 0) {
        imageUrl = [listM.image_list objectAtIndex:0];
    }
    HRWebViewController *businessDetail = [[HRWebViewController alloc]init];
    businessDetail.aUrl = [NSURL URLWithString:listM.article_url];
    businessDetail.image_url = imageUrl;
    businessDetail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:businessDetail animated:NO];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
