//
//  HRHeaderConfigPlist.h
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HRHeaderConfigPlist : NSObject
+ (HRHeaderConfigPlist *)sharedInstance;
+(NSArray *)localHeaderData;
+(NSArray *)localVideoHeaderData;
@end
