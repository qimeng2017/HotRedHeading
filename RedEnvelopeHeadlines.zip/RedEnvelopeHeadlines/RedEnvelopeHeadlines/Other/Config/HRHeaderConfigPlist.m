//
//  HRHeaderConfigPlist.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HRHeaderConfigPlist.h"
#import "HRNewsHeaderModel.h"
#import "HRVideoHeadModel.h"
@implementation HRHeaderConfigPlist
+ (HRHeaderConfigPlist *)sharedInstance
{
    static HRHeaderConfigPlist *_settings = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _settings = [[HRHeaderConfigPlist alloc] init];
    });
    return _settings;
}
+(NSArray *)localHeaderData{
    NSDictionary *dataDict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"headerInfo" ofType:@"plist"]];
    NSArray *headerArr = [dataDict objectForKey:@"Root"];
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dict in headerArr) {
        
        HRNewsHeaderModel*item = [[HRNewsHeaderModel alloc] initWithDictionary:dict error:nil];
        [array addObject:item];
    }
    
    
    return array;
}
+(NSArray *)localVideoHeaderData{
    NSDictionary *dataDict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"videoHeaderInfo" ofType:@"plist"]];
    NSArray *headerArr = [dataDict objectForKey:@"Root"];
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dict in headerArr) {
        HRVideoHeadModel *item = [[HRVideoHeadModel alloc]initWithDictionary:dict error:nil];

        [array addObject:item];
    }
    return array;
}
@end
