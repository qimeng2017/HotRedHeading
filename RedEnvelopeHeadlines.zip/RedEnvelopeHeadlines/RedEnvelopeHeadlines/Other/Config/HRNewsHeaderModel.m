//
//  HRNewsHeaderModel.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HRNewsHeaderModel.h"

@implementation HRNewsHeaderModel
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    return YES;
}
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.categoryId = [aDecoder decodeObjectForKey:@"categoryId"];
        
        self.icon = [aDecoder decodeObjectForKey:@"icon"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.categoryId forKey:@"categoryId"];
    [aCoder encodeObject:self.icon forKey:@"icon"];
}
@end
