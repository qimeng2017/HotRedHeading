//
//  HRVideoHeadModel.h
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface HRVideoHeadModel : JSONModel<NSCoding>
@property (nonatomic, copy) NSString *name;/**<解释*/
@property (nonatomic, strong) NSString *category;/**<解释*/
@property (nonatomic, copy) NSString *icon;

@end
