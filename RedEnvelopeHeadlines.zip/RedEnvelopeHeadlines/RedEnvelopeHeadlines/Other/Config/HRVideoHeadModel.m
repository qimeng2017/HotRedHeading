//
//  HRVideoHeadModel.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/10.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HRVideoHeadModel.h"

@implementation HRVideoHeadModel
+(BOOL)propertyIsOptional:(NSString*)propertyName
{
    return YES;
}
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.category = [aDecoder decodeObjectForKey:@"category"];
        
        self.icon = [aDecoder decodeObjectForKey:@"icon"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.category forKey:@"category"];
    [aCoder encodeObject:self.icon forKey:@"icon"];
}
@end
