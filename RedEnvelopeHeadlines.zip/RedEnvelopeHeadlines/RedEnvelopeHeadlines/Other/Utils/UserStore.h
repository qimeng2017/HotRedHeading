//
//  UserStore.h
//  LotteryNews
//
//  Created by 邹壮壮 on 2016/12/23.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <Foundation/Foundation.h>



typedef void(^sucessCompleteBlock)(NSURLSessionDataTask *task, id responseObject);

typedef void(^failureCompleteBlock)(NSURLSessionDataTask *task, NSError * error);

@interface UserStore : NSObject
+ (UserStore *)sharedInstance;
- (NSString *)idfa;
- (NSString *)verify;
//用户登录
- (void)defaultUser;
-(void)getAccess_token:(NSString *)code sucess:(void(^)( NSDictionary *dict))block;
- (void)loadNewsDataForType:(ScrollDirection)scrollDirection newsType:(NSString *)newsType page:(NSInteger)page ssucessBlock:(sucessCompleteBlock)sucessBlock failureBlock:(failureCompleteBlock)failureBlock;
//抢红包
- (void)robRedBag:(NSInteger)robType ssucessBlock:(sucessCompleteBlock)sucessBlock failureBlock:(failureCompleteBlock)failureBlock;
//ad_manage
- (void)ios_ad_manage;
//签到
- (void)signCount:(NSInteger)count sucessBlock:(sucessCompleteBlock)sucessBlock failureBlock:(failureCompleteBlock)failureBlock;
@end
