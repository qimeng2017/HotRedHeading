//
//  UserStore.m
//  LotteryNews
//
//  Created by 邹壮壮 on 2016/12/23.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "UserStore.h"
#import "NSString+MD5.h"
#import "NSDate+Formatter.h"
#import "HRNetworkTools.h"
#import "NSString+Extension.h"

#import "HRNetworkManager.h"
//#import "WXApiManager.h"
#import "WXApiRequestHandler.h"
#import <AdSupport/AdSupport.h>
#import "ProgressHUD.h"
#import "LNAlertView.h"

@interface UserStore ()

@end
@implementation UserStore
+ (UserStore *)sharedInstance
{
    static UserStore *_sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[UserStore alloc] init];
    });
    
    return _sharedInstance;
}
- (NSString *)idfa{
    NSString*idfa = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    return idfa;
    
}
- (NSString *)verify{
    
    NSString *idfa = [self idfa];
    NSString *date = [NSDate redDateForEveryday];
    NSString *redUrl = [NSString stringWithFormat:@"%@%@FB1C1CE0F269EBDF2B564174F0909E84",idfa,date];
    NSString *verify = [NSString stringToMD5:redUrl];
    return verify;
}
#pragma mark-- 审核状态
- (void)checkReviewTheStatus{
    
    NSString *url = [NSString stringWithFormat:@"%@/review_status?appid=%@&stype=%@",RED_ENVELOP_HOST_NAME,red_appid,red_app_type];
       [[HRNetworkManager shareManager]Get:url Parameters:nil Success:^(NSURLSessionDataTask *task, NSDictionary *responseObject) {
           
       } Failure:^(NSError *error) {
           
       }];
    
}
#pragma mark --用户登录
//默认用户
- (void)defaultUser{
    NSDictionary *userInfo = @{
                               @"city" : @"Bengbu",
                               @"country" : @"CN",
                               @"headimgurl" : @"http://wx.qlogo.cn/mmopen/9xM3cXia6HVM0ibBtbbBmu1iaIDRdp0pNlqh0MkAnQjxItYUh09pz356kxZs67VGoJZ7XuyOQbCxbwrGLibugCEwwDxc5zzqDNY3/0",
                               @"language" : @"zh_CN",
                               @"nickname" : @"恰少年",
                               @"openid" : @"o_k0lwKRNQZXZ1mbc0yrixGkrM44",
                               @"province" : @"Anhui",
                               @"sex" : @1,
                               @"unionid" : @"oszDYvnjGoggsWTshIScOemfEHWU"
                               };
    UserDefaultSetObjectForKey(userInfo, USERINFO);
}
#pragma mark -- 微信登录
-(void)getAccess_token:(NSString *)code sucess:(void(^)( NSDictionary *dict))block

{
    //https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code
    
    NSString *url =[NSString stringWithFormat:@"https://api.weixin.qq.com/sns/oauth2/access_token?appid=%@&secret=%@&code=%@&grant_type=authorization_code",kAuthOpenID,kAuthOpensecret,code];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSURL *zoneUrl = [NSURL URLWithString:url];
        
        NSString *zoneStr = [NSString stringWithContentsOfURL:zoneUrl encoding:NSUTF8StringEncoding error:nil];
        
        NSData *data = [zoneStr dataUsingEncoding:NSUTF8StringEncoding];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (data) {
                
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                
                /*
                 
                 {
                 
                 "access_token" = "OezXcEiiBSKSxW0eoylIeJDUKD6z6dmr42JANLPjNN7Kaf3e4GZ2OncrCfiKnGWiusJMZwzQU8kXcnT1hNs_ykAFDfDEuNp6waj-bDdepEzooL_k1vb7EQzhP8plTbD0AgR8zCRi1It3eNS7yRyd5A";
                 
                 "expires_in" = 7200;
                 
                 openid = oyAaTjsDx7pl4Q42O3sDzDtA7gZs;
                 
                 "refresh_token" = "OezXcEiiBSKSxW0eoylIeJDUKD6z6dmr42JANLPjNN7Kaf3e4GZ2OncrCfiKnGWi2ZzH_XfVVxZbmha9oSFnKAhFsS0iyARkXCa7zPu4MqVRdwyb8J16V8cWw7oNIff0l-5F-4-GJwD8MopmjHXKiA";
                 
                 scope = "snsapi_userinfo,snsapi_base";
                 
                 }
                 
                 */
                
                NSString * access_token = [dic objectForKey:@"access_token"];
                
                NSString *openid = [dic objectForKey:@"openid"];
                [self getUserInfo:access_token openid:openid sucess:^(NSDictionary *dict) {
                    block(dict);
                }];
            }
            
        });
        
    });
    
}
//三.根据第二步获取的token和openid来获取用户的相关信息

-(void)getUserInfo:(NSString *)token openid:(NSString *)openid sucess:(void(^)( NSDictionary *dict))block
{
    
    // https://api.weixin.qq.com/sns/userinfo?access_token=ACCESS_TOKEN&openid=OPENID
    
    NSString *url =[NSString stringWithFormat:@"https://api.weixin.qq.com/sns/userinfo?access_token=%@&openid=%@",token,openid];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSURL *zoneUrl = [NSURL URLWithString:url];
        
        NSString *zoneStr = [NSString stringWithContentsOfURL:zoneUrl encoding:NSUTF8StringEncoding error:nil];
        
        NSData *data = [zoneStr dataUsingEncoding:NSUTF8StringEncoding];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (data) {
                
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                
                /*
                 
                 {
                 
                 city = Haidian;
                 
                 country = CN;
                 
                 headimgurl = "http://wx.qlogo.cn/mmopen/FrdAUicrPIibcpGzxuD0kjfnvc2klwzQ62a1brlWq1sjNfWREia6W8Cf8kNCbErowsSUcGSIltXTqrhQgPEibYakpl5EokGMibMPU/0";
                 
                 language = "zh_CN";
                 
                 nickname = "xxx";
                 
                 openid = oyAaTjsDx7pl4xxxxxxx;
                 
                 privilege =    (
                 
                 );
                 
                 province = Beijing;
                 
                 sex = 1;
                 
                 unionid = oyAaTjsxxxxxxQ42O3xxxxxxs;
                 
                 }
                 
                 */
                UserDefaultSetObjectForKey(dic, @"weixinUserInfo");
                block(dic);
            }
            
        });
        
    });
    
}
- (void)loadNewsDataForType:(ScrollDirection)scrollDirection newsType:(NSString *)newsType page:(NSInteger)page ssucessBlock:(sucessCompleteBlock)sucessBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *p = [NSString stringWithFormat:@"%ld",(long)page];
    NSString *url = [[NSString stringWithFormat:@"%@/news/%@?page=%@",INFAMATION_HOST_NAME,newsType,p] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            sucessBlock(task,responseObject);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSString *errorCode = [NSString stringWithFormat:@"%ld",(long)error.code];
        //是否以5开头的错误
        if ([errorCode hasPrefix:@"5"]||[errorCode hasPrefix:@"-1004"]) {
            [[ProgressHUD sharedInstance]showErrorOrSucessWithStatus:YES message:NSLocalizedString(@"serviceError", @"")];
        }else{
            failureBlock(task,error);
        }
    }];
}
- (void)robRedBag:(NSInteger)robType ssucessBlock:(sucessCompleteBlock)sucessBlock failureBlock:(failureCompleteBlock)failureBlock{
     NSString *bagstType = [NSString stringWithFormat:@"%ld",(long)robType];
    NSString *idfa = [[UserStore sharedInstance]idfa];
    NSString *verify = [[UserStore sharedInstance]verify];
    NSDictionary *userInfo = UserDefaultObjectForKey(@"userInfo");
    NSString *unionid = [userInfo objectForKey:@"unionid"];
    NSString *openid = [userInfo objectForKey:@"openid"];
    
    NSString *weixinId = unionid ?unionid:openid;
    NSString *urlStr = [NSString stringWithFormat:@"%@/hongbao_system/grant",RED_ENVELOP_HOST_NAME];
    NSDictionary *parameters = @{@"idfa":idfa,
                                 @"verify":verify,
                                 @"weixin_id":weixinId,
                                 @"bags_type":bagstType
                                 };
    [[HRNetworkTools sharedNetworkTools]GET:urlStr parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if ([responseObject isKindOfClass:[NSDictionary class]]){
            NSNumber *statusNumber = [responseObject objectForKey:@"status"];
            NSString *status = [NSString stringWithFormat:@"%@",statusNumber];
            if ([status isEqualToString:@"0"]){
                sucessBlock(task,responseObject);
            }else{
              [[ProgressHUD sharedInstance]showErrorOrSucessWithStatus:YES message:NSLocalizedString(@"serviceError", @"")];
            }
        }
        sucessBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         NSString *errorCode = [NSString stringWithFormat:@"%ld",(long)error.code];
        //是否以5开头的错误
        if ([errorCode hasPrefix:@"5"]||[errorCode hasPrefix:@"-1004"]) {
            [[ProgressHUD sharedInstance]showErrorOrSucessWithStatus:YES message:NSLocalizedString(@"serviceError", @"")];
        }else{
            failureBlock(task,error);
        }
    }];
}
//ad_manage
- (void)ios_ad_manage{
    NSString *idfa = [[UserStore sharedInstance]idfa];
    NSString *verify = [[UserStore sharedInstance]verify];
    NSDictionary *userInfo = UserDefaultObjectForKey(@"userInfo");
    NSString *unionid = [userInfo objectForKey:@"unionid"];
    NSString *openid = [userInfo objectForKey:@"openid"];
    NSString *weixinId = unionid ?unionid:openid;
    NSString *urlStr = [NSString stringWithFormat:@"%@/ios_ad_manage",RED_ENVELOP_HOST_NAME];
    NSDictionary *parameters = @{@"idfa":idfa,
                                 @"verify":verify,
                                 @"weixin_id":weixinId,
                                 @"appid":red_appid,
                                 @"stype":red_app_type
                                 };
    [[HRNetworkTools sharedNetworkTools]GET:urlStr parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSNumber *codelNum = [responseObject objectForKey:@"code"];
        NSInteger code = [codelNum integerValue];
        if (code == 1) {
            NSString *title = [responseObject objectForKey:@"title"];
            NSString *message = [responseObject objectForKey:@"message"];
            NSString *downloadurl = [responseObject objectForKey:@"download_url"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self downLoad:title message:message downloadurl:downloadurl];
            });
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSString *errorCode = [NSString stringWithFormat:@"%ld",(long)error.code];
        //是否以5开头的错误
        if ([errorCode hasPrefix:@"5"]||[errorCode hasPrefix:@"-1004"]) {
            [[ProgressHUD sharedInstance]showErrorOrSucessWithStatus:YES message:NSLocalizedString(@"serviceError", @"")];
        }else{
            
        }
    }];

}
- (void)downLoad:(NSString *)title message:(NSString *)message downloadurl:(NSString *)downloadurl{
    LNAlertView *lnalertView = [[LNAlertView alloc]initWithTitle:title message: message cancelButtonTitle:@"取消"];
    [lnalertView addDefaultStyleButtonWithTitle:@"去下载" handler:^(LNAlertView *alertView, LNAlertButtonItem *buttonItem) {
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:downloadurl]];
        [alertView dismiss];
        
    }];
    
    [lnalertView show];
}
//签到
- (void)signCount:(NSInteger)count sucessBlock:(sucessCompleteBlock)sucessBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *sign_day = [NSString stringWithFormat:@"%ld",(long)count];
    NSString *idfa = [[UserStore sharedInstance]idfa];
    NSString *verify = [[UserStore sharedInstance]verify];
    NSDictionary *userInfo = UserDefaultObjectForKey(@"userInfo");
    NSString *unionid = [userInfo objectForKey:@"unionid"];
    NSString *openid = [userInfo objectForKey:@"openid"];
    NSString *weixinId = unionid ?unionid:openid;
    NSString *urlStr = [NSString stringWithFormat:@"%@/hongbao_system/grant",RED_ENVELOP_HOST_NAME];
    NSDictionary *parameters = @{@"idfa":idfa,@"verify":verify,@"weixin_id":weixinId,@"bags_type":@"3",@"sign_day":sign_day};
    [[HRNetworkTools sharedNetworkTools]GET:urlStr parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucessBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSString *errorCode = [NSString stringWithFormat:@"%ld",(long)error.code];
        //是否以5开头的错误
        if ([errorCode hasPrefix:@"5"]||[errorCode hasPrefix:@"-1004"]) {
            [[ProgressHUD sharedInstance]showErrorOrSucessWithStatus:YES message:NSLocalizedString(@"serviceError", @"")];
        }else{
            failureBlock(task,error);
        }
    }];
    
}
@end
