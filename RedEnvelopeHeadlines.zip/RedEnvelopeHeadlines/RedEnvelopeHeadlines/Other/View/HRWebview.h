//
//  HRWebview.h
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/13.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@class HRWebview;
@protocol HRWebviewDelegate <NSObject>
@optional
- (void)zlcwebView:(HRWebview *)webview didFinishLoadingURL:(NSURL *)URL;
- (void)zlcwebView:(HRWebview *)webview didFailToLoadURL:(NSURL *)URL error:(NSError *)error;
- (void)zlcwebView:(HRWebview *)webview shouldStartLoadWithURL:(NSURL *)URL;
- (void)zlcwebViewDidStartLoad:(HRWebview *)webview;

@end
@interface HRWebview : UIView<WKNavigationDelegate, WKUIDelegate, UIWebViewDelegate>
#pragma mark - Public Properties

//zlcdelegate
@property (nonatomic, weak) id <HRWebviewDelegate> delegate;

// The main and only UIProgressView
@property (nonatomic, strong) UIProgressView *progressView;
// The web views
// Depending on the version of iOS, one of these will be set
@property (nonatomic, strong) WKWebView *wkWebView;
@property (nonatomic, strong) UIWebView *uiWebView;



#pragma mark - Initializers view
- (instancetype)initWithFrame:(CGRect)frame;


#pragma mark - Static Initializers
@property (nonatomic, strong) UIBarButtonItem *actionButton;
@property (nonatomic, strong) UIColor *tintColor;
@property (nonatomic, strong) UIColor *barTintColor;
@property (nonatomic, assign) BOOL actionButtonHidden;
@property (nonatomic, assign) BOOL showsURLInNavigationBar;
@property (nonatomic, assign) BOOL showsPageTitleInNavigationBar;

//Allow for custom activities in the browser by populating this optional array
@property (nonatomic, strong) NSArray *customActivityItems;

#pragma mark - Public Interface


// Load a NSURLURLRequest to web view
// Can be called any time after initialization
- (void)loadRequest:(NSURLRequest *)request;

// Load a NSURL to web view
// Can be called any time after initialization
- (void)loadURL:(NSURL *)URL;

// Loads a URL as NSString to web view
// Can be called any time after initialization
- (void)loadURLString:(NSString *)URLString;


// Loads an string containing HTML to web view
// Can be called any time after initialization
- (void)loadHTMLString:(NSString *)HTMLString;
- (void)stopLoading;

- (void)reload;
- (void)goBack;
- (void)goForward;
- (void)hr_evaluateJavaScript:(NSString*)javaScriptString completionHandler:(void (^ _Nullable)(_Nullable id, NSError * _Nullable error))completionHandler;
@end
