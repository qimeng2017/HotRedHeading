//
//  RedBagSignInMainView.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/20.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "RedBagSignInMainView.h"
#import "SignBtn.h"
#import "UserStore.h"
#import "NSDate+Formatter.h"
#define Width_Space 10.0f        // 2个按钮之间的横间距
static NSString * const singCount = @"singCount";
@interface RedBagSignInMainView ()
@property (weak, nonatomic) IBOutlet UIImageView *signMainImageView;
@property (weak, nonatomic) IBOutlet UIButton *signBtn;
@property (weak, nonatomic) IBOutlet UIView *signRecoderView;
@property (nonatomic, assign) NSInteger recoderCount;
@property (nonatomic, assign) NSInteger signedCount;

@end
@implementation RedBagSignInMainView
- (IBAction)cancleAction:(id)sender {
    [self removeFromSuperview];
}
- (IBAction)signBtnAction:(id)sender {
    UIButton *btn = (UIButton *)sender;
    btn.selected = !btn.selected;
    _signBtn.userInteractionEnabled = YES;
    
    _signedCount+=1;
    self.recoderCount = _signedCount;
    NSNumber *number = [NSNumber numberWithInteger:_signedCount];
    UserDefaultSetObjectForKey(number, singCount);
    [[UserStore sharedInstance]signCount:_signedCount sucessBlock:^(NSURLSessionDataTask *task, id responseObject) {
        
    } failureBlock:^(NSURLSessionDataTask *task, NSError *error) {
        
    }];
}

- (void)awakeFromNib{
    [super awakeFromNib];
    self.signedCount = 0;
    
    
    [self setUp];
}
-(void)setUp{
    NSArray *arr = @[@{@"day":@"1天",@"gold":@"10金币"},
                     @{@"day":@"2天",@"gold":@"20金币"},
                     @{@"day":@"3天",@"gold":@"30金币"},
                     @{@"day":@"4天",@"gold":@"40金币"},
                     @{@"day":@"5天",@"gold":@"50金币"},
                     @{@"day":@"6天",@"gold":@"60金币"},
                     @{@"day":@"7天",@"gold":@"70金币"}
                     ];
    CGFloat width = (_signRecoderView.frame.size.width - 6*Width_Space)/7;
    for (NSInteger i = 0; i< 7; i++) {
        NSDictionary *dic = [arr objectAtIndex:i];
        NSString *day = [dic objectForKey:@"day"];
        NSString *gold = [dic objectForKey:@"gold"];
        SignBtn  *dayGoldBtn = [[SignBtn alloc]initWithDay:day gold:gold width:width];
        dayGoldBtn.tag = 100+i;
        [_signRecoderView addSubview:dayGoldBtn];
        
    }
}
- (void)layoutSubviews{
    [super layoutSubviews];
    CGFloat width = (_signRecoderView.frame.size.width - 6*Width_Space)/7;
    for (__block NSInteger i=0; i<7; i++) {
        UIView *view = [self viewWithTag:100+i];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_signRecoderView.mas_left).with.offset(i*(width+Width_Space));
            make.top.mas_equalTo(_signRecoderView.mas_top).with.offset(0);
        }];
    }
}
- (void)show{
    //显示时检查有多少天已经签到
    NSNumber *number = UserDefaultObjectForKey(singCount);
    _signedCount = [number integerValue];
    self.recoderCount = _signedCount;
    NSString *weak = [NSDate weekdayStringFromDate:[NSDate date]];
   
    if (!self.superview) {
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        [keyWindow addSubview:self];
        self.center = CGPointMake(CGRectGetMidX(keyWindow.bounds), CGRectGetMidY(keyWindow.bounds));
        [keyWindow addSubview:self];
        [keyWindow bringSubviewToFront:self];
        [self setTransform:CGAffineTransformMakeScale(0.5f, 0.5f)];
    }
    __weak RedBagSignInMainView *weakSelf = self;
    [UIView animateWithDuration:0.3f delay:0.f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [weakSelf setTransform:CGAffineTransformMakeScale(1.0, 1.0)];
    } completion:NULL];
    
}
- (void)setRecoderCount:(NSInteger)recoderCount{
    [self signSelected:recoderCount];
}
- (void)signSelected:(NSInteger)count{
    for (int i= 0; i<count; i++) {
        SignBtn *view = (SignBtn *)[self viewWithTag:100+i];
        view.isSelected = YES;
    }
}
@end
