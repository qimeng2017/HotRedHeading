//
//  RedEnvelopeView.h
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/21.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum RobRedEnvelopType {
    RobRedEnvelopFirstEnterApp=0,
    RobRedEnvelopShare,
    RobRedEnvelopRead,
    RobRedEnvelopSign,
    RobRedEnvelopInvitation,
    RobRedEnvelopComment=5,
    RobRedEnvelopVideo=6
} RobRedEnvelopType;

@protocol RedEnvelopeViewDelegate <NSObject>

- (void)removeFrom:(RobRedEnvelopType)type;
- (void)robSucess:(RobRedEnvelopType)type;


@end
@interface RedEnvelopeView : UIView
@property (nonatomic,weak)id<RedEnvelopeViewDelegate>delegate;
@property (nonatomic,assign) RobRedEnvelopType robType;
- (void)show;
@end
