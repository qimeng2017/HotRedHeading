//
//  RedEnvelopeView.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/21.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "RedEnvelopeView.h"
#import "UserStore.h"
@interface RedEnvelopeView ()<CAAnimationDelegate>
@property (weak, nonatomic) IBOutlet UILabel *goldTipLable;
@property (weak, nonatomic) IBOutlet UIImageView *robImageView;

@end
@implementation RedEnvelopeView
- (void)awakeFromNib{
    [super awakeFromNib];
    _goldTipLable.hidden = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    [_robImageView addGestureRecognizer:tap];
}
- (IBAction)cancleAction:(id)sender {
    
    [self remove];
    if (_delegate&&[_delegate respondsToSelector:@selector(removeFrom:)]) {
        [_delegate removeFrom:_robType];
    }
}

- (void)show{
    if (!self.superview) {
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        [keyWindow addSubview:self];
        self.center = CGPointMake(CGRectGetMidX(keyWindow.bounds), CGRectGetMidY(keyWindow.bounds));
        [keyWindow addSubview:self];
        [keyWindow bringSubviewToFront:self];
        [self setTransform:CGAffineTransformMakeScale(0.5f, 0.5f)];
    }
    __weak RedEnvelopeView *weakSelf = self;
    [UIView animateWithDuration:0.3f delay:0.f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [weakSelf setTransform:CGAffineTransformMakeScale(1.0, 1.0)];
    } completion:NULL];
}
- (void)tapAction:(UITapGestureRecognizer *)tap{
    _robImageView.userInteractionEnabled = NO;
    [_robImageView.layer addAnimation:[self KeyframeAnimation] forKey:@"transform"];
    _robImageView.layer.zPosition = 50;
    [[UserStore sharedInstance]robRedBag:_robType ssucessBlock:^(NSURLSessionDataTask *task, id responseObject) {
        [_robImageView.layer removeAllAnimations];
        _robImageView.hidden = YES;
        _goldTipLable.hidden = NO;
        _goldTipLable.text = [NSString stringWithFormat:@"%@",[responseObject objectForKey:@"info"]];
        if (_delegate&&[_delegate respondsToSelector:@selector(robSucess:)]) {
            [_delegate robSucess:_robType];
        }
        
    } failureBlock:^(NSURLSessionDataTask *task, NSError *error) {
        
    }];
}


- (void)remove{
    
    __weak RedEnvelopeView *weakSelf = self;
    [UIView animateWithDuration:.4f delay:.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        weakSelf.alpha = 0.f;
    } completion:^(BOOL finished) {
        [weakSelf removeFromSuperview];
        
    }];
}
#pragma mark ====旋转动画======


- (CAKeyframeAnimation *)KeyframeAnimation{
    CAKeyframeAnimation *theAnimation = [CAKeyframeAnimation animation];
    
    //    CATransform3DMakeRotation(CGFloat angle, CGFloat x, CGFloat y, CGFloat z); 第一个参数是旋转角度，后面三个参数形成一个围绕其旋转的向量，起点位置由UIView的center属性标识。
    theAnimation.values = [NSArray arrayWithObjects:
                           [NSValue valueWithCATransform3D:CATransform3DMakeRotation(0, 0, 0.5, 0)],
                           [NSValue valueWithCATransform3D:CATransform3DMakeRotation(3.13, 0, 0.5, 0)],
                           [NSValue valueWithCATransform3D:CATransform3DMakeRotation(6.26, 0, 0.5, 0)],
                           nil];
    
    
    theAnimation.cumulative = YES;
    //    每个帧的时间=总duration/(values.count - 1)
    // 间隔时间 频率
    theAnimation.duration = 1;
    // 重复次数
    theAnimation.repeatCount = MAXFLOAT;
    
    
    // 取消反弹// 告诉在动画结束的时候不要移除
    theAnimation.removedOnCompletion = NO;
    // 始终保持最新的效果
    theAnimation.fillMode = kCAFillModeForwards;
    
    theAnimation.delegate = self;
    return theAnimation;
}

@end
