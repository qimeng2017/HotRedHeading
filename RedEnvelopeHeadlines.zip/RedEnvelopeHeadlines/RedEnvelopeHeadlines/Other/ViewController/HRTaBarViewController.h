//
//  HRTaBarViewController.h
//  HotRedHeadlines
//
//  Created by 邹壮壮 on 2016/12/5.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HRTaBarViewController : UITabBarController
- (void)checkUpdate;
- (void)getUserInfo;
- (void)appearRedBag;
@end
