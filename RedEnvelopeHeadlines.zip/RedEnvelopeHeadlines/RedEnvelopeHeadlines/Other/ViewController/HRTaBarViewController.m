//
//  HRTaBarViewController.m
//  HotRedHeadlines
//
//  Created by 邹壮壮 on 2016/12/5.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "HRTaBarViewController.h"
#import "HRNavigationViewController.h"


#import "HRNetworkTools.h"
#import "SGAlertView.h"

#import "HRSystem.h"
#import "NewsViewController.h"
#import "VideoViewController.h"
@interface HRTaBarViewController ()<SGAlertViewDelegate>
{
   
    NSString *download_url;
    SGAlertView *alert;
}
@property (nonatomic, assign) BOOL            isShakeCanChangeSkin;
@property (nonatomic, strong) NSNumber        *timeNumber;

@property (nonatomic, strong) NSTimer         *timer;
@end

@implementation HRTaBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBar.tintColor = [UIColor redColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [UITabBar appearance].translucent = NO;
    [[UITabBar appearance] setBarTintColor:[UIColor whiteColor]];
    NewsViewController *newsVC = [[NewsViewController alloc]init];
    [self addChildViewController:newsVC withImage:[UIImage imageNamed:@"tabbar_zhuyemianb"] selectedImage:[UIImage imageNamed:@"tabbar_zhuyemian"] withTittle:@"新闻"];
    VideoViewController *videoVC = [[VideoViewController alloc]init];
    [self addChildViewController:videoVC withImage:nil selectedImage:nil withTittle:@"视频"];
   
    
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    NSString *buildVersionUpdate = [NSString stringWithFormat:@"%@-update",[HRSystem bundleBuildVersion]];
    NSString *isUpdate = UserDefaultObjectForKey(buildVersionUpdate);
   
}






- (void)addChildViewController:(UIViewController *)controller withImage:(UIImage *)image selectedImage:(UIImage *)selectImage withTittle:(NSString *)tittle{
    UIColor *colorSelect=[UIColor redColor];
    HRNavigationViewController *nav = [[HRNavigationViewController alloc] initWithRootViewController:controller];
    
    [nav.tabBarItem setImage:image];
    [nav.tabBarItem setSelectedImage:selectImage];
    //    nav.tabBarItem.title = tittle;
    //    controller.navigationItem.title = tittle;
    controller.title = tittle;//这句代码相当于上面两句代码
    [nav.tabBarItem setTitleTextAttributes:@{NSForegroundColorAttributeName:colorSelect} forState:UIControlStateSelected];
    nav.tabBarItem.titlePositionAdjustment = UIOffsetMake(0, -3);
    [self addChildViewController:nav];
}





//code = 1弹出升级提醒,mode = 1  升级提醒，但不强制
- (void)accordingUpdate:(NSString *)title content:(NSString *)content type:(SGAlertViewBottomViewType)type{
    if (!alert) {
        alert = [[SGAlertView alloc] initWithTitle:title  delegate:self contentTitle:content alertViewBottomViewType:type];
        [alert show];
    }
    
}


- (void)didSelectedSureButtonClick {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:download_url]];
}

-(void)didReceiveMemoryWarning {
    
    
}


@end
