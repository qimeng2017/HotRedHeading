//
//  HRWebViewController.h
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/13.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "BaseViewController.h"

@interface HRWebViewController : BaseViewController
- (instancetype)initWithURL:(NSURL *)url;
@property (nonatomic,strong)NSURL *aUrl;
@property (nonatomic,strong)NSString *image_url;

@property (nonatomic, assign) BOOL showSubTitle;/**<默认显示子标题>*/
@property (nonatomic, strong) NSString *navigationTitle;/**<导航栏标题*/
@end
