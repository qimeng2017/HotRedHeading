//
//  HRWebViewController.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/13.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HRWebViewController.h"
#import "HRWebview.h"
#import "HRFlashLable.h"
#import "MSSBrowseDefine.h"
#import "SuspensionView.h"
#import "RedEnvelopeView.h"
#import "LKBubble.h"
#import "UserStore.h"
@interface HRWebViewController ()<HRWebviewDelegate,RedEnvelopeViewDelegate>{
    HRWebview *_webView;
    UIButton                     *backBtn;
    UIButton                     *shareBtn;
    
}
@property (nonatomic, strong) __block NSMutableArray  *imageArr;
@property (nonatomic, strong) HRFlashLable     *tipFlashLable;
@property (nonatomic, strong) SuspensionView *suspensionView;
@end

@implementation HRWebViewController
@synthesize showSubTitle;
@synthesize navigationTitle;
- (instancetype)initWithURL:(NSURL *)url
{
    if (self = [super init]) {
        self.aUrl = url;
        self.showSubTitle = NO;
    }
    return self;
}
- (NSMutableArray *)imageArr{
    if (_imageArr == nil) {
        _imageArr = [NSMutableArray array];
    }
    return _imageArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setInitUI];
}
- (void)back
{ 
    _webView.delegate = nil;
    [_webView stopLoading];
    if (self.presentingViewController.presentedViewController == self.navigationController) {
        [self dismissViewControllerAnimated:YES completion:NULL];
    }
    else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)viewDidAppear:(BOOL)animated
{
    
    [super viewDidAppear:animated];
    NSLog(@"viewDidAppear");
    NSURLRequest *request = [NSURLRequest requestWithURL:self.aUrl];
    [_webView loadRequest:request];
   
}
- (void)setInitUI{
    
    if (_webView == nil) {
        HRWebview *webView = [[HRWebview alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, CGRectGetHeight(self.view.frame))];
        
        webView.delegate = self;
        [self.view addSubview:webView];
        _webView = webView;
    }
    //返回按钮
    backBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 20, 44, 44)];
    [backBtn setImage:[UIImage imageNamed:@"video_fanhui"] forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    [self.view bringSubviewToFront:backBtn];
    // 上面的分享按钮
    shareBtn = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth-54, 20, 44, 44)];
    [shareBtn setImage:[UIImage imageNamed:@"video_fenxiang"] forState:UIControlStateNormal];
    [shareBtn addTarget:self action:@selector(shareToWX) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:shareBtn];
    shareBtn.userInteractionEnabled = NO;
    [self.view bringSubviewToFront:shareBtn];
    [self.view addSubview:self.tipFlashLable];
    [self.view addSubview:self.suspensionView];
    __weak HRWebViewController *weakSelf = self;
    _suspensionView.ClickDragViewBlock = ^(SuspensionView *dragView){
        [weakSelf redEnvelopeView:RobRedEnvelopRead];
    };
}


#pragma mark - UIWebView delegate
- (void)zlcwebViewDidStartLoad:(HRWebview *)webview{
    if (self.tipFlashLable) {
        [self.tipFlashLable removeFromSuperview];
    }
}
- (void)zlcwebView:(HRWebview *)webview didFinishLoadingURL:(NSURL *)URL{
    [self getImageUrlByJS:webview];
    shareBtn.userInteractionEnabled = YES;
}
/*
 *通过js获取htlm中图片url
 */
-(void)getImageUrlByJS:(HRWebview *)wkWebView
{
    
    //查看大图代码
    //js方法遍历图片添加点击事件返回图片个数
    static  NSString * const jsGetImages =
    @"function getImages(){\
    var objs = document.getElementsByTagName(\"img\");\
    var imgScr = '';\
    for(var i=0;i<objs.length;i++){\
    imgScr = imgScr + objs[i].src + '+';\
    };\
    return imgScr;\
    };";
    //添加点击事件
    static  NSString * const jsOnclick =
    @"function registerImageClickAction(){\
    var imgs=document.getElementsByTagName('img');\
    var length=imgs.length;\
    for(var i=0;i<length;i++){\
    img=imgs[i];\
    img.onclick=function(){\
    window.location.href='image-preview:'+this.src}\
    }\
    };";
    //用js获取全部图片
    [wkWebView hr_evaluateJavaScript:jsGetImages completionHandler:nil];
    [wkWebView hr_evaluateJavaScript:jsOnclick completionHandler:nil];
    
    NSString *js2=@"getImages()";
    
    
    [wkWebView hr_evaluateJavaScript:js2 completionHandler:^(id _Nullable Result, NSError * _Nullable error) {
        NSString *resurlt=[NSString stringWithFormat:@"%@",Result];
        
        if([resurlt hasPrefix:@"+"])
        {
            resurlt=[resurlt substringFromIndex:1];
        }
        NSLog(@"result===%@",resurlt);
        NSArray *arr = [resurlt componentsSeparatedByString:@"+"];
        for (NSString *imageUrl in arr) {
            [self.imageArr addObject:imageUrl];
        }
        
        if (_imageArr.count >=2) {
            [_imageArr removeLastObject];
        }
        
    }];
    NSString *jsOnclickImage = @"registerImageClickAction()";
    [wkWebView hr_evaluateJavaScript:jsOnclickImage completionHandler:nil];
    
}

- (void)zlcwebView:(HRWebview *)webview shouldStartLoadWithURL:(NSURL *)URL{
    //预览图片
    if ([URL.scheme isEqualToString:@"image-preview"]) {
        NSString* path = [URL.absoluteString substringFromIndex:[@"image-preview:" length]];
        
        path = [path stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        for (NSInteger index = 0; index < self.imageArr.count; index++) {
            NSString *url = self.imageArr[index];
            if ([url isEqualToString:path]) {
    
                [self selectedIndex:index];
                break;
            }
        }
        
       
    }
}
#pragma mark -- 查看图片
- (void)selectedIndex:(NSInteger)selectedIndex{
    NSMutableArray *browseItemArray = [[NSMutableArray alloc]init];
    for (NSInteger index = 0; index < self.imageArr.count; index++) {
        
        NSString *url = self.imageArr[index];
        MSSBrowseModel *browseItem = [[MSSBrowseModel alloc]init];
        browseItem.bigImageUrl = url;// 加载网络图片大图地址
        // browseItem.smallImageView = imageView;// 小图
        [browseItemArray addObject:browseItem];
    }
    MSSBrowseNetworkViewController *bvc = [[MSSBrowseNetworkViewController alloc]initWithBrowseItemArray:browseItemArray currentIndex:selectedIndex];
    //    bvc.isEqualRatio = NO;// 大图小图不等比时需要设置这个属性（建议等比）
    [bvc showBrowseViewController];
    
}
- (void)zlcwebView:(HRWebview *)webview didFailToLoadURL:(NSURL *)URL error:(NSError *)error{
    
}
#pragma mark -- 提示
- (HRFlashLable *)tipFlashLable{
    if (_tipFlashLable == nil) {
        _tipFlashLable = [[HRFlashLable alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth/2, 80)];
        _tipFlashLable.text = @"正在努力加载中!";
        _tipFlashLable.center = CGPointMake(kScreenWidth/2, SCREEN_HEIGHT/2);
        _tipFlashLable.textColor = [UIColor grayColor];
        _tipFlashLable.font = [UIFont systemFontOfSize:20];
        _tipFlashLable.haloColor = [UIColor redColor];
        _tipFlashLable.haloWidth = 0.8;
        _tipFlashLable.haloDuration = 2;
        _tipFlashLable.numberOfLines = 2;
        _tipFlashLable.textAlignment = NSTextAlignmentCenter;
    }
    return _tipFlashLable;
}
#pragma mark --红包
- (SuspensionView *)suspensionView{
    if (_suspensionView == nil) {
        NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"suspensionView" owner:nil options:nil];
        _suspensionView = [nibView objectAtIndex:0];
        _suspensionView.frame = web_suspensionViewFram;
        _suspensionView.isKeepBounds = YES;
    }
    return _suspensionView;
}
- (void)robSucess:(RobRedEnvelopType)type{
    if (type == RobRedEnvelopRead) {
        [_suspensionView remove];
    }
}
- (void)removeFrom:(RobRedEnvelopType)type{
    [[UserStore sharedInstance]ios_ad_manage];
}
- (void)redEnvelopeView:(RobRedEnvelopType)type{
    NSArray* nibView =  [[NSBundle mainBundle] loadNibNamed:@"RedEnvelopeView" owner:nil options:nil];
    RedEnvelopeView *redBagView = [nibView objectAtIndex:0];
    redBagView.delegate = self;
    redBagView.robType = type;
    [redBagView show];
}
#pragma mark -- 分享
#pragma mark- 分享
- (void)shareToWX{
    [self systemShare];
}
//系统方法
- (void)systemShare{
    NSString *url = [NSString stringWithFormat:@"%@?stype=share",self.aUrl];
    NSURL *urlToShare = [NSURL URLWithString:url];
    UIActivityViewController *activityViewController = [[UIActivityViewController alloc]
                                                        initWithActivityItems:@[urlToShare]
                                                        applicationActivities:nil];
     activityViewController.excludedActivityTypes = @[UIActivityTypeAssignToContact,UIActivityTypePostToFacebook,UIActivityTypePostToTwitter,UIActivityTypeMessage,UIActivityTypeMail,UIActivityTypeCopyToPasteboard,UIActivityTypeAssignToContact,UIActivityTypeAddToReadingList,UIActivityTypePostToFlickr,UIActivityTypeAirDrop,UIActivityTypeOpenInIBooks,UIActivityTypePostToVimeo,UIActivityTypePrint];
     [self presentViewController:activityViewController animated:YES completion:nil];
    __weak HRWebViewController *weakSelf = self;
    activityViewController.completionWithItemsHandler = ^(UIActivityType __nullable activityType, BOOL completed, NSArray * __nullable returnedItems, NSError * __nullable activityError){
        if (completed) {
            if ([activityType isEqualToString:@"com.tencent.xin.sharetimeline"]) {
                [weakSelf redEnvelopeView:RobRedEnvelopShare];
            }
            
        }
    };
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
