//
//  VideoViewController.m
//  RedEnvelopeHeadlines
//
//  Created by 邹壮壮 on 2017/3/12.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "VideoViewController.h"
#import "HRHeaderConfigPlist.h"
#import "HRSegmentView.h"
#import <MJRefresh/MJRefresh.h>
@interface VideoViewController ()

@end

@implementation VideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];    
    self.navigationController.navigationBarHidden = YES;

    NSArray *arr = [HRHeaderConfigPlist localVideoHeaderData];
   
    HRSegmentView *view =   [[HRSegmentView alloc]initWithFrame:CGRectMake(0, 20, self.view.frame.size.width, 44.0f) titles:arr headerType:@"video" clickBlick:^(NSInteger index) {
        
    }];
    [self.view addSubview:view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
